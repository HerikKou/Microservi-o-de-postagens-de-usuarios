package Postagens.Postagens.Config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.WebClient;
@Configuration
public class WebClientConfig {
    @Value("${usuario.service.token}")
    private  String token;
    @Value("${usuario.service.url}")
    private String baseUrl;

    @Bean
    public WebClient webClient() {
    return WebClient.builder()//webclient builder
            .baseUrl(baseUrl)//define a URL base para o WebClient
            .defaultHeader("Content-Type", "application/json")//define o cabeçalho padrão para todas as requisições
            .filter((request, next) -> {//adiciona o token de autenticação ao cabeçalho de cada requisição
                return next.exchange(//próximo filtro na cadeia
                     ClientRequest.from(request)//cria uma nova requisição com base na requisição original
                        .header("Authorization", "Bearer " + token)//adiciona o cabeçalho de autorização com o token
                        .build()//constrói a nova requisição
                );
            })
            .build();//constrói o WebClient
}
}
