package Postagens.Postagens.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;

import Postagens.Postagens.DTO.PostagensDTO;
import Postagens.Postagens.DTO.UserDTO;
import Postagens.Postagens.ExceptionsHandle.ArquivoInvalido;
import Postagens.Postagens.ExceptionsHandle.ArquivoVazio;
import Postagens.Postagens.ExceptionsHandle.NaoEncontrado;

import Postagens.Postagens.Model.Postagens;
import Postagens.Postagens.Repository.PostagensRepository;
import reactor.core.publisher.Mono;

@Service
public class PostagensService {
    private final PostagensRepository repository;
    private final WebClient webclient;
    @Value("${usuario.service.token}")
    private String token;
    public PostagensService(PostagensRepository repository, WebClient webClient) {
        this.repository = repository;
        this.webclient = webClient;
       
    }

    public Mono<Postagens> salvarPostagem(Long userId,MultipartFile file, PostagensDTO postagensDTO)throws NaoEncontrado, ArquivoInvalido, ArquivoVazio, IllegalStateException, IOException {
        return  webclient.get()
                .uri("/encontrarUsuario/{id}", userId)//url da api de usuario
                .retrieve()//responsável por enviar a requisição e receber a resposta
                .bodyToMono(UserDTO.class)//converte o corpo da resposta em um objeto do tipo UserDTO
                .switchIfEmpty(Mono.error(new NaoEncontrado("Usuário não encontrado.")))//se o usuário não for encontrado, lança uma exceção personalizada
                //Lógica para salvar a postagem
                .flatMap(response -> {//se o usuário for encontrado, prossegue com o processamento da postagem
                    if (file.isEmpty()) {//verifica se o arquivo está vazio
                        return Mono.error(new ArquivoVazio("O arquivo está vazio."));
                    }
                    String arquivo = file.getOriginalFilename();//obtém o nome original do arquivo
                   if(arquivo == null || !(arquivo.endsWith(".png") || arquivo.endsWith(".jpg") || arquivo.endsWith(".jpeg"))) {//verifica se o arquivo é uma imagem válida
                        return Mono.error(new ArquivoInvalido("Tipo de arquivo inválido. Apenas arquivos PNG, JPG e JPEG são permitidos."));
                    }
                    String pasta = "downloads";//diretório onde os arquivos serão salvos
                    File diretorio = new File(pasta);//cria o diretório se ele não existir
                    if (!diretorio.exists()) {//verifica se o diretório existe
                        diretorio.mkdirs();
                    }
                    String nomeDoArquivo = UUID.randomUUID().toString() + "_" + arquivo;//gera um nome único para o arquivo
                    Path pastaDoArquivo = Paths.get(pasta, nomeDoArquivo);//caminho completo do arquivo
                    try {
                        file.transferTo(pastaDoArquivo.toFile());//envia o arquivo para o diretório especificado
                       
                       
                    
                    } catch (IOException e) {
                        return Mono.error(new RuntimeException("Erro ao salvar o arquivo.",e));//trata os erros ao salvar o arquivo
                    }
                    Postagens postagem = new Postagens();//cria uma nova postagem
                    postagem.setUserId(userId);
                    postagem.setImgUrl(pastaDoArquivo.toString());
                    postagem.setDataPostagem(LocalDateTime.now());
                    postagem.setDescricao(postagensDTO.getDescricao());
                    postagem.setCurtidas(postagensDTO.getCurtidas());
                   return Mono.fromCallable(() -> repository.save(postagem));
                });
       
    }
}
