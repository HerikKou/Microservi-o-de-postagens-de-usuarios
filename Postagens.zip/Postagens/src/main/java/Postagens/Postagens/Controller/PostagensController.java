
package Postagens.Postagens.Controller;

import java.io.IOException;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import Postagens.Postagens.DTO.PostagensDTO;
import Postagens.Postagens.ExceptionsHandle.ArquivoInvalido;
import Postagens.Postagens.ExceptionsHandle.ArquivoVazio;
import Postagens.Postagens.ExceptionsHandle.NaoEncontrado;
import Postagens.Postagens.Model.Postagens;
import Postagens.Postagens.Service.PostagensService;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/postagens")
public class PostagensController {
    private final PostagensService postagensService;

    public PostagensController(PostagensService postagensService) {
        this.postagensService = postagensService;
    }

    @PostMapping("/criar")
    public Mono<ResponseEntity<Postagens>> criarPostagem( @RequestParam("userId") Long userId,@RequestParam("file") MultipartFile file,  @RequestParam("descricao") String descricao, @RequestParam("curtidas") int curtidas) throws IllegalStateException, NaoEncontrado, ArquivoInvalido, ArquivoVazio, IOException {
        PostagensDTO dto = new PostagensDTO();
        dto.setDescricao(descricao);
        dto.setCurtidas(curtidas);

        return postagensService.salvarPostagem(userId, file, dto)
                .map(ResponseEntity::ok);
    }
}