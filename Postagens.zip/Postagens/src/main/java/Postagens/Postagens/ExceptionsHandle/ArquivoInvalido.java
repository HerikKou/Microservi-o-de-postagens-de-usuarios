package Postagens.Postagens.ExceptionsHandle;

public class ArquivoInvalido extends Exception {
    public ArquivoInvalido(String message) {
        super(message);
    }
    
}
