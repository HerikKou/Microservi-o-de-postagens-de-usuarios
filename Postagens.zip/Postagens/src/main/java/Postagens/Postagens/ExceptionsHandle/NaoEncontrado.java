package Postagens.Postagens.ExceptionsHandle;

public class NaoEncontrado extends Exception {
    public NaoEncontrado(String message) {
        super(message);
    }
    
}
