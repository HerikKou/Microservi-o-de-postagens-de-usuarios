package Postagens.Postagens.ExceptionsHandle;

public class ArquivoVazio extends Exception {
    public ArquivoVazio(String message) {
        super(message);
    }
    
}
