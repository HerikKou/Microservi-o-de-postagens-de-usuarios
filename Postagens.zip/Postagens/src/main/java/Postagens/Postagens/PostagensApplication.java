package Postagens.Postagens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostagensApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostagensApplication.class, args);
	}

}
