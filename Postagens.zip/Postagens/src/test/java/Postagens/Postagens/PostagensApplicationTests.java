package Postagens.Postagens;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostagensApplicationTests {

	@Test
	void contextLoads() {
	}

}
