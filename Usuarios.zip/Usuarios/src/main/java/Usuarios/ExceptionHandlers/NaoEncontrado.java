package Usuarios.ExceptionHandlers;

public class NaoEncontrado extends Exception {
    public NaoEncontrado (String menssagem) {
            super(menssagem);
        
    }
}
