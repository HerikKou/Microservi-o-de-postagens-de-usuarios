package Usuarios.ExceptionHandlers;

public class Existente extends Exception {
    public Existente(String message) {
        super(message);
    }
    
}
